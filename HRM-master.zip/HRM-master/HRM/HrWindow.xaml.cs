﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HRM
{
    /// <summary>
    /// Interaction logic for HrWindow.xaml
    /// </summary>
    public partial class HrWindow : Window
    {
        private int selectedResumeId = 0;
        private int selectedEmployeeId = 0;
        private int selectedEmployee2Id = 0;
        private int selectedVacancyId = 0;

        public HrWindow()
        {
           
            InitializeComponent();
            /*DataContext = datas.emp;
            employeeGrid2.ItemsSource = DataContext.*/
            loadResumes();
            loadVacances();
            loadEmployees();
            loadEmployees2();
            loadAllEmployess();
        }
        private void loadResumes()
        {
            resumesGrid.ItemsSource = Helper.context.resume.ToList();
        }

        private void loadVacances()
        {
            vacanciesGrid.ItemsSource = Helper.context.vacancy.Where(vacancy => vacancy.id_company == datas.emp.compania).ToList();
        }

        private void loadEmployees()
        {
            employeeGrid.ItemsSource = Helper.context.employees.Where(empl => empl.compania == datas.emp.compania).ToList();
        }

        private void loadEmployees2()
        {
            var query = from res in Helper.context.resume join sd in Helper.context.employees on res.id_sotrud equals sd.id
                        where sd.compania == datas.emp.compania
                        select new {id = sd.id, Фамилия = res.f , Имя = res.i, Отчество = res.o };
            //employeeGrid2.ItemsSource = Helper.context.employees.Where(employee => employee.compania == datas.emp.compania).ToList();
            employeeGrid2.ItemsSource = query.ToList();
        }
        private void loadAllEmployess()
        {
            allEmplsGrid.ItemsSource = Helper.context.employees.Where(empl => empl.compania == datas.emp.compania).ToList();
        }

        private void createTaskButton_Click(object sender, RoutedEventArgs e)
        {
            task newTask = new task()
            {
                task1 = taskName.Text,
                start_time = DateTime.Now,
                end_time = Convert.ToDateTime(expTime.Text),
                id_sotrud = selectedEmployee2Id
            };
            Helper.context.task.Add(newTask);
            Helper.context.SaveChanges();
            MessageBox.Show("Задача создана");
        }

        private void addEmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            resume resume1 = Helper.context.resume.Where(resume => resume.id == selectedResumeId).FirstOrDefault();
            employees employee = Helper.context.employees.Where(empl => empl.id == resume1.id_sotrud).FirstOrDefault();

            employee.compania = datas.emp.compania;
            Helper.context.SaveChanges();
            MessageBox.Show("Сотрудник успешно добавлен");
        }

        private void dismissEmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            employees employee = Helper.context.employees.Where(empl => empl.id == selectedEmployeeId).FirstOrDefault();

            rating newRating = new rating()
            {
                srok_vipolnenie_zadach = duration.Text,
                kachestvo_rabot = quality.Text,
                zaverchenieZadach = completion.Text,
                itog = summary.Text,
                id_sotrud = employee.id,
            };

            Helper.context.rating.Add(newRating);

            employee.compania = null;
            Helper.context.SaveChanges();
            employeeGrid.ItemsSource = null;
            loadEmployees();
        }
        private void resumesGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedRow = resumesGrid.SelectedItem as resume;

            if (selectedRow != null)
            {
                selectedResumeId = selectedRow.id;
            }
        }

        private void employeeGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedRow = employeeGrid.SelectedItem as employees;

            if (selectedRow != null)
            {
                selectedEmployeeId = selectedRow.id;
            }
        }

        private void employeeGrid2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedRow = employeeGrid2.SelectedItem as employees;

            if (selectedRow != null)
            {
                selectedEmployee2Id = selectedRow.id;
            }
        }

        private void updateEmployees_Click(object sender, RoutedEventArgs e)
        {
            allEmplsGrid.ItemsSource = null;
            loadAllEmployess();
        }

        private void createVacancyButton_Click(object sender, RoutedEventArgs e)
        {
            new CreateVacancyWindow().Show();
        }

        private void updateVacancyGridButton_Click(object sender, RoutedEventArgs e)
        {
            vacanciesGrid.ItemsSource = null;
            loadVacances();
        }

        private void vacanciesGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedRow = vacanciesGrid.SelectedItem as vacancy;

            if (selectedRow != null)
            {
                selectedVacancyId = selectedRow.id;
            }
        }

        private void removeVacancyButton_Click(object sender, RoutedEventArgs e)
        {
            vacancy vacancyForRemove = Helper.context.vacancy.Where(vacancy => vacancy.id == selectedVacancyId).FirstOrDefault();
            Helper.context.vacancy.Remove(vacancyForRemove);
            Helper.context.SaveChanges();
            MessageBox.Show("Вакансия удалена");
        }
    }
}
