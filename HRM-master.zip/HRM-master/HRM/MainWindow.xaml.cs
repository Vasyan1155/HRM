﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HRM
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
            loadVacancy();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            new Login_registration().Show();
        }

        private void createCompanyButton_Click(object sender, RoutedEventArgs e)
        {
            new CreateCompanyWindow().Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void loadVacancy()
        {
            var query = from vacancy in Helper.context.vacancy
                        join company in Helper.context.Kompania on vacancy.id_company equals company.id
                        
                        select new { id = vacancy.id, Компания = company.name,Зарплата = vacancy.zp, Описание_вакансии = vacancy.opicanie_vacancy};
            
            dataGrid.ItemsSource = query.ToList();
        }

        private void otklikGrid_Click(object sender, RoutedEventArgs e)
        {
            if (datas.emp != null)
            {
                var selectedRow = dataGrid.SelectedItem as vacancy;

                Otklik otkl = new Otklik()
                {

                    id_sotrud = datas.emp.id,
                    id_vacansy = selectedRow.id
                };
                Helper.context.Otklik.Add(otkl);

                Helper.context.SaveChanges();
            }
            else {

                MessageBox.Show("Вы не авторизованы! ");
            };
        }
    }
}
